/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bestbrighness_system;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author CC
 */
public class SalesMenu {
private String CustomerName;
private String OrderDate;
private int CustormerId;
private int OrderId;
private double Discount;
private int Quantity;
 
 public SalesMenu(){
String CustomerName = " ";
String OrderDate =" ";
int CustormerId=0;
int OrderId =0;
double Discount = 0.30;
int Quantity= 0;
}
 
 public SalesMenu(String CustomerName ,String OrderDate ,int CustormerId ,int OrderId ,double Discount ,int Quantity ){
 this.CustomerName= CustomerName;
 this.CustormerId=CustormerId;
 this.Discount=Discount;
 this.OrderDate=OrderDate;
 this.OrderId=OrderId;
 this.Quantity=Quantity;
 }
 public String getCustomerName() {
        return CustomerName;
 
}
 public String getOrderDate() {
        return OrderDate;
 }
 public int getCustormerId() {
        return CustormerId;
 }
 public double getDiscount() {
        return Discount;
}
  public int getOrderId() {
        return OrderId;
  }
  public int getQuantity() {
        return Quantity;
}
  public void setCustomerName(String CustomerName) {
    this.CustomerName= CustomerName;
  }
  public void setCustormerId(int CustormerId){
 this.CustormerId=CustormerId;
}
  public void setDiscount(double Discount){
 this.Discount=Discount;
  }
  
  public void setOrderDate(String OrderDate){
 this.OrderDate=OrderDate;
  }
  public void setOrderId(int OrderId){
 this.OrderId=OrderId;
  }
  public void setQuantity(int Quantity){
 this.Quantity=Quantity;
  }
  
  Connection con ;
  
 public void Connect(){
 String url ="jdbc:derby://localhost:1527/Login_Details";
 try{
 Connection con = DriverManager.getConnection(url);
 System.out.println("Connected");
 }
 catch(Exception e){
 System.out.println(e.getMessage());
 }
 } 
 
 
}
 