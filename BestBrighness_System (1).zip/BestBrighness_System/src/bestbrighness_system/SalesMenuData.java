/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bestbrighness_system;

/**
 *
 * @author CC
 */
class SalesMenuData {

    SalesMenuData(String customerName, String orderDateStr, int customerId, int orderId, double discount, int quantity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
